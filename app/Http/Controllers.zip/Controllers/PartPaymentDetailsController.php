<?php

namespace App\Http\Controllers;

use App\Models\part_payment_details;
use Illuminate\Http\Request;

class PartPaymentDetailsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(part_payment_details $part_payment_details)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(part_payment_details $part_payment_details)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, part_payment_details $part_payment_details)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(part_payment_details $part_payment_details)
    {
        //
    }
}
