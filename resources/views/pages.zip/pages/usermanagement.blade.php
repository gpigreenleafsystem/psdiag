i@extends('layouts.app', [
  'namePage' => 'User Management',
  'class' => 'sidebar-mini',
  'activePage' => 'usermanagement',
])

@section('content')
<div class="panel-header panel-header-sm">
<div class="content">
<div class="row">
rrtrtrtr
</div>
</div>
</div>
@endsection
